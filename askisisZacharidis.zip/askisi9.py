numPropaidia = [1,2,3,4,5,6,7,8,9,10]

for i in numPropaidia:
    for j in numPropaidia:
        print((i * j ))
    print(" ")

#kapos tha ginetai pio apla stin python SIGOURA ! episis pos kaneis print xoris allagi grammis

    